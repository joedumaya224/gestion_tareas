<h1>Tarea Completada</h1>
<p>La tarea "{{ $tarea->titulo }}" ha sido marcada como completada.</p>
