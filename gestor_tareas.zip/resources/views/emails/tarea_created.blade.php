<h1>Nueva Tarea Creada</h1>
<p>Se ha creado una nueva tarea: {{ $tarea->titulo }}</p>