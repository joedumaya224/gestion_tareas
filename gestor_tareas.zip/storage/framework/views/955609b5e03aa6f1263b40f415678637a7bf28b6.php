

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Lista de Tareas</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success mb-4 bg-green-500 text-white p-4 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($tareas->isEmpty()): ?>
            <div class="alert alert-info mt-3 bg-blue-100 text-blue-800 p-4 rounded">
                No tienes tareas pendientes.
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300 rounded-lg shadow-md">
                    <thead>
                        <tr class="bg-gray-200">
                            <th class="py-2 px-4 text-left text-gray-600 font-semibold">Título</th>
                            <th class="py-2 px-4 text-left text-gray-600 font-semibold">Descripción</th>
                            <th class="py-2 px-4 text-left text-gray-600 font-semibold">Fecha de Vencimiento</th>
                            <th class="py-2 px-4 text-left text-gray-600 font-semibold">Estado</th>
                            <th class="py-2 px-4 text-left text-gray-600 font-semibold">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b hover:bg-gray-100">
                                <td class="py-2 px-4 text-gray-700"><?php echo e($tarea->titulo); ?></td>
                                <td class="py-2 px-4 text-gray-700"><?php echo e($tarea->descripcion); ?></td>
                                <td class="py-2 px-4 text-gray-700"><?php echo e(\Carbon\Carbon::parse($tarea->fecha_vencimiento)->format('d/m/Y')); ?></td>
                                <td class="py-2 px-4">
                                    <?php if($tarea->completado): ?>
                                        <span class="bg-green-200 text-green-800 px-2 py-1 rounded-full">Completada</span>
                                    <?php else: ?>
                                        <span class="bg-red-200 text-red-800 px-2 py-1 rounded-full">Pendiente</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-2 px-4 flex space-x-2">
                                    <?php if(!$tarea->completado): ?>
                                        <form action="<?php echo e(route('tareas.complete', $tarea)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="bg-blue-500 text-white rounded-full px-5 py-2 text-sm hover:bg-blue-600" title="Marcar como completada y enviar al correo">
                                                Finalizar
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('tareas.destroy', $tarea)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar esta tarea?');" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="bg-red-500 text-white rounded-full px-5 py-2 text-sm hover:bg-red-600" title="Eliminar tarea">
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <?php echo e($tareas->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\gestion_tareas\resources\views/tareas/index.blade.php ENDPATH**/ ?>