<h1>Tarea Completada</h1>
<p>La tarea "<?php echo e($tarea->titulo); ?>" ha sido marcada como completada.</p>
<?php /**PATH C:\Users\DELL\Documents\gestion_tareas\resources\views/emails/tarea_completed.blade.php ENDPATH**/ ?>